'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import { Loader2, Image as ImageIcon, X, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useWorkflowStore } from '@/store/workflowStore';
import { useAuthStore } from '@/store/authStore';
import { useTranslation } from '@/lib/i18n';
import { renderImage, fetchUser, fetchReferenceLibrary, fetchSchemaTemplates, ReferenceItem, SchemaTemplateItem, fetchPublicSettings } from '@/lib/api';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/navigation';

// Dynamic import for Monaco Editor (SSR disabled)
const MonacoEditor = dynamic(() => import('@monaco-editor/react'), {
    ssr: false,
    loading: () => (
        <div className="h-[500px] bg-slate-100 animate-pulse rounded-lg" />
    ),
});

export function ReviewStep() {
    const {
        language,
        paperContent,
        generatedSchema,
        setGeneratedSchema,
        referenceImages,
        addReferenceImage,
        removeReferenceImage,
        setGeneratedImage,
        setCurrentStep,
        addToHistory,
        sessionId,
        chartLanguage,
    } = useWorkflowStore();
    const t = useTranslation(language);
    const [isRendering, setIsRendering] = useState(false);
    const [mobileTab, setMobileTab] = useState<'source' | 'editor' | 'reference'>('editor');
    const [cost, setCost] = useState<number>(0);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const router = useRouter();

    const [systemReferences, setSystemReferences] = useState<ReferenceItem[]>([]);
    const [schemaTemplates, setSchemaTemplates] = useState<SchemaTemplateItem[]>([]);

    useEffect(() => {
        (async () => {
            try {
                const [refs, tpls, settings] = await Promise.all([
                    fetchReferenceLibrary(),
                    fetchSchemaTemplates(),
                    fetchPublicSettings()
                ]);
                setSystemReferences(refs);
                setSchemaTemplates(tpls);
                setCost(settings.cost_image_rendering || 1);
            } catch {
                // ignore loading errors
            }
        })();
    }, []);

    const validateSchema = (schema: string): boolean => {
        return schema.includes('---BEGIN PROMPT---') && schema.includes('---END PROMPT---');
    };

    const handleRender = async () => {
        const { token } = useAuthStore.getState();
        if (!token) {
             useWorkflowStore.getState().setAuthModalTab('login');
             useWorkflowStore.getState().setAuthModalOpen(true);
             return;
        }

        if (!validateSchema(generatedSchema)) {
            toast.error(t('schemaError'));
            return;
        }

        setIsRendering(true);
        try {
            const response = await renderImage(generatedSchema, referenceImages, sessionId || undefined, chartLanguage);
            if (response.imageUrl) {
                setGeneratedImage(response.imageUrl);
                addToHistory({ schema: generatedSchema, imageUrl: response.imageUrl });
                setCurrentStep(3);
                toast.success('Image rendered successfully!');
                try {
                    const user = await fetchUser();
                    useAuthStore.getState().setUser(user);
                } catch {}
            } else {
                toast.error('No image was generated. Please check your model configuration.');
            }
        } catch (error) {
            const isUnauthorized = error instanceof Error && (((error as any).status === 401) || error.message === 'UNAUTHORIZED' || error.message.includes('Could not validate credentials'));
            if (isUnauthorized) {
                toast.error(t('unauthorized'));
                router.push('/login');
            } else {
                toast.error(t('generationFailed'));
            }
        } finally {
            setIsRendering(false);
        }
    };

    const addLibraryImage = async (urlOrData: string) => {
        try {
            if (urlOrData.startsWith('data:')) {
                addReferenceImage(urlOrData);
            } else {
                const res = await fetch(urlOrData);
                const blob = await res.blob();
                const reader = new FileReader();
                const base64Promise = new Promise<string>((resolve, reject) => {
                    reader.onloadend = () => {
                        resolve(reader.result as string);
                    };
                    reader.onerror = reject;
                });
                reader.readAsDataURL(blob);
                const dataUrl = await base64Promise;
                addReferenceImage(dataUrl);
            }
            toast.success(language === 'zh' ? '已加入参考图片' : 'Added to references');
        } catch {
            toast.error(language === 'zh' ? '加载参考图片失败' : 'Failed to load reference image');
        }
    };

    const handleDrop = useCallback((e: React.DragEvent) => {
        e.preventDefault();
        const files = Array.from(e.dataTransfer.files);
        files.forEach((file) => {
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    if (event.target?.result) {
                        addReferenceImage(event.target.result as string);
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    }, [addReferenceImage]);

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = Array.from(e.target.files || []);
        files.forEach((file) => {
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    if (event.target?.result) {
                        addReferenceImage(event.target.result as string);
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    };

    return (
        <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="max-w-7xl mx-auto"
        >
            {/* Desktop Layout */}
            <div className="hidden md:grid md:grid-cols-2 gap-6">
                {/* Left: Source Input */}
                <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
                    <h3 className="font-semibold text-slate-900 mb-4">{t('sourceInput')}</h3>
                    <div className="h-[400px] overflow-auto bg-slate-50 rounded-lg p-4 font-mono text-sm text-slate-600">
                        {paperContent || 'No content'}
                    </div>
                </div>

                {/* Right: Schema Editor */}
                <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
                    <h3 className="font-semibold text-slate-900 mb-4">{t('blueprintEditor')}</h3>
                    <div className="h-[400px] rounded-lg overflow-hidden border border-slate-200">
                        <MonacoEditor
                            height="100%"
                            defaultLanguage="markdown"
                            value={generatedSchema}
                            onChange={(value) => setGeneratedSchema(value || '')}
                            theme="vs-light"
                            options={{
                                minimap: { enabled: false },
                                fontSize: 13,
                                fontFamily: 'JetBrains Mono, Fira Code, monospace',
                                wordWrap: 'on',
                                lineNumbers: 'on',
                                padding: { top: 16 },
                            }}
                        />
                    </div>
                </div>
            </div>

            {/* Mobile Layout */}
            <div className="md:hidden">
                <Tabs value={mobileTab} onValueChange={(v) => setMobileTab(v as any)}>
                    <TabsList className="grid w-full grid-cols-3 bg-slate-100">
                        <TabsTrigger value="source">{t('sourceInput')}</TabsTrigger>
                        <TabsTrigger value="editor">{t('blueprintEditor')}</TabsTrigger>
                        <TabsTrigger value="reference">{t('referenceImages')}</TabsTrigger>
                    </TabsList>
                    <TabsContent value="source" className="mt-4">
                        <div className="bg-white rounded-xl border border-slate-200 p-4 h-[500px] overflow-auto font-mono text-sm">
                            {paperContent || 'No content'}
                        </div>
                    </TabsContent>
                    <TabsContent value="editor" className="mt-4">
                        <div className="h-[500px] rounded-lg overflow-hidden border border-slate-200">
                            <MonacoEditor
                                height="100%"
                                defaultLanguage="markdown"
                                value={generatedSchema}
                                onChange={(value) => setGeneratedSchema(value || '')}
                                theme="vs-light"
                                options={{
                                    minimap: { enabled: false },
                                    fontSize: 13,
                                    wordWrap: 'on',
                                }}
                            />
                        </div>
                    </TabsContent>
                    <TabsContent value="reference" className="mt-4">
                        <ReferenceImagePanel
                            images={referenceImages}
                            onAdd={addReferenceImage}
                            onRemove={removeReferenceImage}
                            onDrop={handleDrop}
                            fileInputRef={fileInputRef}
                            onFileSelect={handleFileSelect}
                            t={t}
                        />
                    </TabsContent>
                </Tabs>
            </div>

            {/* Reference Images (Desktop) */}
            <div className="hidden md:block mt-6">
                <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
                    <h3 className="font-semibold text-slate-900 mb-2">{t('referenceImages')}</h3>
                    <p className="text-sm text-slate-500 mb-4">{t('addReference')}</p>
                    <ReferenceImagePanel
                        images={referenceImages}
                        onAdd={addReferenceImage}
                        onRemove={removeReferenceImage}
                        onDrop={handleDrop}
                        fileInputRef={fileInputRef}
                        onFileSelect={handleFileSelect}
                        t={t}
                    />
                    <div className="mt-6">
                        <h4 className="font-medium text-slate-800 mb-2">{t('recommendedReferences')}</h4>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                            {systemReferences.map((item, idx) => (
                                <div key={idx} className="border border-slate-200 rounded-lg overflow-hidden bg-white">
                                    <img src={item.image_data} alt={item.title} className="w-full h-28 object-cover" />
                                    <div className="p-2 flex items-center justify-between">
                                        <span className="text-xs text-slate-600 truncate">{item.title}</span>
                                        <Button size="sm" variant="outline" className="h-7 px-2"
                                            onClick={() => addLibraryImage(item.image_data)}>
                                            {t('addToReferences')}
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                    <div className="mt-6">
                        <h4 className="font-medium text-slate-800 mb-2">{t('recommendedTemplates')}</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {schemaTemplates.map((tpl) => (
                                <div key={tpl.id} className="border border-slate-200 rounded-lg p-3 bg-white">
                                    <div className="text-sm font-medium text-slate-800">{tpl.title}</div>
                                    <div className="text-xs text-slate-500 mt-1">{tpl.layout}</div>
                                    <div className="mt-2">
                                        <Button size="sm" className="h-8" onClick={() => setGeneratedSchema(tpl.content)}>
                                            {t('insertTemplate')}
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* Render Button */}
            <div className="mt-6 flex justify-end">
                <Button
                    onClick={handleRender}
                    disabled={isRendering || !generatedSchema.trim()}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white active:scale-95 transition-transform"
                >
                    {isRendering ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            {t('rendering')}
                        </>
                    ) : (
                        <>
                                <ImageIcon className="w-4 h-4 mr-2" />
                                {t('renderImage')} <span className="text-xs opacity-80 ml-1">({cost} 积分)</span>
                            </>
                        )}
                    </Button>
            </div>
        </motion.div>
    );
}

interface ReferenceImagePanelProps {
    images: string[];
    onAdd: (image: string) => void;
    onRemove: (index: number) => void;
    onDrop: (e: React.DragEvent) => void;
    fileInputRef: React.RefObject<HTMLInputElement | null>;
    onFileSelect: (e: React.ChangeEvent<HTMLInputElement>) => void;
    t: ReturnType<typeof useTranslation>;
}

function ReferenceImagePanel({
    images,
    onRemove,
    onDrop,
    fileInputRef,
    onFileSelect,
    t,
}: ReferenceImagePanelProps) {
    return (
        <div className="space-y-4">
            {/* Drop Zone */}
            <div
                onDrop={onDrop}
                onDragOver={(e) => e.preventDefault()}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center cursor-pointer hover:border-indigo-400 hover:bg-indigo-50/50 transition-colors"
            >
                <Upload className="w-8 h-8 mx-auto text-slate-400 mb-2" />
                <p className="text-sm text-slate-500">{t('dragDropImages')}</p>
                <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={onFileSelect}
                />
            </div>

            {/* Image Grid */}
            {images.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    {images.map((img, index) => (
                        <div key={index} className="relative group">
                            <img
                                src={img}
                                alt={`Reference ${index + 1}`}
                                className="w-full h-24 object-cover rounded-lg border border-slate-200"
                            />
                            <button
                                onClick={() => onRemove(index)}
                                className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                                <X className="w-3 h-3" />
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}
