(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_ad8d1ddc._.js",
  "static/chunks/src_e2b78f1e._.js"
],
    source: "dynamic"
});
