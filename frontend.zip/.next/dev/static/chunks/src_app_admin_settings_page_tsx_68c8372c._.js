(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_94d271a3._.js",
  "static/chunks/src_9e21455a._.js"
],
    source: "dynamic"
});
